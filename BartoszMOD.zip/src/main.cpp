#include <geode/geode.hpp>

using namespace geode;

class BartoszMOD : public Mod {
public:
    BartoszMOD() : Mod("BartoszMOD") {}

    void onInit() override {
        log::info("BartoszMOD initialized!");
        createMenu();
    }

    void createMenu() {
        // Create the main mod menu
        Menu::add("BartoszMOD", [this]() {
            showMainMenu();
        });
    }

    void showMainMenu() {
        // Add options for features
        Menu::add("Level Bypass", [this]() { levelBypass(); });
        Menu::add("Auto-Clicker", [this]() { startAutoClicker(); });
        Menu::add("Noclip", [this]() { toggleNoclip(); });
    }

    void levelBypass() {
        log::info("Level bypass activated!");
        // Implement the level bypass logic here
    }

    void startAutoClicker() {
        log::info("Auto-clicker activated!");
        // Implement auto-clicker functionality here
    }

    void toggleNoclip() {
        static bool noclipEnabled = false;
        noclipEnabled = !noclipEnabled;
        log::info("Noclip {}", noclipEnabled ? "enabled" : "disabled");

        if (noclipEnabled) {
            // Example: Enable noclip
            // You need to find the correct function or method to toggle noclip
            // e.g., Player::get()->setNoclip(true);
        } else {
            // Disable noclip
            // e.g., Player::get()->setNoclip(false);
        }
    }
};

// Create and register the mod
GDEMOD_REGISTER(BartoszMOD);
