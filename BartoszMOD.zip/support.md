Edit this file to change your mod's support info, or delete it if you don't need it.
